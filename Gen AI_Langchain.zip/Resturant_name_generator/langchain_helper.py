
from langchain.llms import OpenAi
from langchain.prompts import PromptTemplate
from langchain.chain import LLMChain
from langchain.chains import SimpleSequentialChain
from langchain.chains import SequentialChain
from secret_key import openapi_key


import os
os.environ["OPENAI_API_KEY"]=openapi_key
llm=OpenAi(temperature=0.6)

def generate_res_name_and_menu(cuisine):

    prompt_template_name=PromptTemplate(
    input_var=["Cuisine"],
    template="Hi I want to open a resturant for {Cuisine} food. Suggest me a unique name"
)

    name_chain=LLMChain(llm=llm,prompt=prompt_template_name,output_key="restaurant_name")




    prompt_template_items=PromptTemplate(
        input_var=["restaurant_name"],
        template="""suggest me some menu items for {restaurant_name} return it as a comma separated list"""
    )

    food_item_chain=LLMChain(llm=llm,prompt=prompt_template_items,output_key="menu_items")


    chain=SequentialChain(
        chains=[name_chain,food_item_chain],
        input_variables=["cuisine"]
        output_variables=["restaurant_name","menu_items"]
    )

    response=chain({"cuisine":cuisine})
    return response


if __name__=="__main__":
    print(generate_res_name_and_menu("pakistani"))
