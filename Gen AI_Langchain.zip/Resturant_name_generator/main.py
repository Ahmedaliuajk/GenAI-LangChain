# pip install streamlit
import langchain_helper


import streamlit as st

st.title("Resturant Name Generator")

cuisine=st.sidebar.selectbox("pick a cuisine",("Pakistani","Lebanese","Arabic"))


def generate_res_name_and_menu(cuisine):
    return{
        "resturant_name":"Neelum Delights",
        "menu_items":"Biryani,BBQ"

    }


if cuisine:
    response=langchain_helper.generate_res_name_and_menu(cuisine)
    st.header(response["restaurant_name"].strip())
    menu_items=response["menu_items"].strip().split(",")
    st.write("**Menu Items**")
    for item in menu_items:
        st.write(",",item)
